# Mark 112 Nanotech + JARVIS

Projeto-fonte experimental para **Minecraft Java 1.21.11 + Fabric**, pensado para PojavLauncher/Android. A armadura usa o modelo cúbico padrão do Minecraft, com texturas de armadura personalizadas e três visuais: branco/dourado, preto tático e vermelho/dourado.

A interface JARVIS é uma tela holográfica interativa; ela controla materialização, diagnóstico de integridade, fabricação dos kits, poderes e portal por coordenadas.

**Estado honesto:** o projeto-fonte foi preparado e passou por verificações estáticas de JSON/estrutura. Não foi possível compilar nem executar no Minecraft/Pojav neste ambiente, porque Gradle e as dependências Fabric/Minecraft não estão disponíveis. Este ZIP não é um JAR pronto.

Consulte `LEIA-ME.txt` para detalhes de recursos, controles, limitações e instruções de compilação.
