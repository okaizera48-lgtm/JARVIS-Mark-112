package br.jarvis.mark112;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** A validated coordinate destination request from the client-side JARVIS portal panel. */
public record PortalPayload(int x, int y, int z, String dimension) implements CustomPayload {
    public static final Id<PortalPayload> ID = new Id<>(Identifier.of(Mark112Nanotech.MOD_ID, "coordinate_portal"));
    public static final PacketCodec<RegistryByteBuf, PortalPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, PortalPayload::x,
            PacketCodecs.VAR_INT, PortalPayload::y,
            PacketCodecs.VAR_INT, PortalPayload::z,
            PacketCodecs.STRING, PortalPayload::dimension,
            PortalPayload::new
    );

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
