package br.jarvis.mark112;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record ToggleSuitPayload(boolean active) implements CustomPayload {
    public static final Id<ToggleSuitPayload> ID = new Id<>(Identifier.of(Mark112Nanotech.MOD_ID, "toggle_suit"));
    public static final PacketCodec<RegistryByteBuf, ToggleSuitPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.BOOL, ToggleSuitPayload::active,
            ToggleSuitPayload::new
    );

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
