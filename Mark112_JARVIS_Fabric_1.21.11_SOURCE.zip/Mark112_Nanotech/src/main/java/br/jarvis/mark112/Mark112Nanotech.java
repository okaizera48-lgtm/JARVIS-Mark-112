package br.jarvis.mark112;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemGroups;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Mark112Nanotech implements ModInitializer {
    public static final String MOD_ID = "mark112_nanotech";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.register();
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(ModItems.NANOTECH_HELMET);
            entries.add(ModItems.NANOTECH_CHESTPLATE);
            entries.add(ModItems.NANOTECH_LEGGINGS);
            entries.add(ModItems.NANOTECH_BOOTS);
            entries.add(ModItems.BLACK_HELMET);
            entries.add(ModItems.BLACK_CHESTPLATE);
            entries.add(ModItems.BLACK_LEGGINGS);
            entries.add(ModItems.BLACK_BOOTS);
            entries.add(ModItems.RED_HELMET);
            entries.add(ModItems.RED_CHESTPLATE);
            entries.add(ModItems.RED_LEGGINGS);
            entries.add(ModItems.RED_BOOTS);
            entries.add(ModItems.NANOTECH_GAUNTLET);
            entries.add(ModItems.INFINITY_GAUNTLET);
            entries.add(ModItems.JARVIS_CORE);
        });

        PayloadTypeRegistry.playC2S().register(ToggleSuitPayload.ID, ToggleSuitPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SuitActionPayload.ID, SuitActionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(PortalPayload.ID, PortalPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SuitStatePayload.ID, SuitStatePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ToggleSuitPayload.ID, (payload, context) ->
                context.server().execute(() -> SuitManager.setActive(context.player(), payload.active())));
        ServerPlayNetworking.registerGlobalReceiver(SuitActionPayload.ID, (payload, context) ->
                context.server().execute(() -> SuitManager.performAction(context.player(), payload.action())));
        ServerPlayNetworking.registerGlobalReceiver(PortalPayload.ID, (payload, context) ->
                context.server().execute(() -> SuitManager.openCoordinatePortal(context.player(), payload)));

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> SuitManager.sync(handler.player));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> SuitManager.cleanup(handler.player));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                SuitManager.tick(player);
            }
        });
        LOGGER.info("Mark 112 Nanotech / JARVIS inicializado. Build experimental; compile e teste ainda necessários.");
    }
}
