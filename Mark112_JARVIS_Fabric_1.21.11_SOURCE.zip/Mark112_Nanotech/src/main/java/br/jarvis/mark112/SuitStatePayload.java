package br.jarvis.mark112;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server-authoritative JARVIS state mirrored to the client HUD. */
public record SuitStatePayload(boolean active, boolean combatMode, boolean faceplateOpen) implements CustomPayload {
    public static final Id<SuitStatePayload> ID = new Id<>(Identifier.of(Mark112Nanotech.MOD_ID, "suit_state"));
    public static final PacketCodec<RegistryByteBuf, SuitStatePayload> CODEC = PacketCodec.tuple(
            PacketCodecs.BOOL, SuitStatePayload::active,
            PacketCodecs.BOOL, SuitStatePayload::combatMode,
            PacketCodecs.BOOL, SuitStatePayload::faceplateOpen,
            SuitStatePayload::new
    );

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
