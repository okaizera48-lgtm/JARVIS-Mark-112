package br.jarvis.mark112;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Server-authoritative logic for the Minecraft-style Mark 112 prototype.
 * Armor remains ordinary blocky Minecraft equipment; this class controls
 * materialization, piece-specific powers, the JARVIS panel, and coordinate travel.
 */
public final class SuitManager {
    private static final Set<UUID> ACTIVE = new HashSet<>();
    private static final Set<UUID> FLIGHT_GRANTED = new HashSet<>();
    private static final Set<UUID> COMBAT_MODE = new HashSet<>();
    private static final Set<UUID> FACEPLATE_OPEN = new HashSet<>();
    private static final Map<UUID, Set<EquipmentSlot>> MATERIALIZED_SLOTS = new HashMap<>();
    private static final Map<UUID, Map<Integer, Integer>> COOLDOWNS = new HashMap<>();

    private SuitManager() {}

    public static boolean isActive(ServerPlayerEntity player) { return ACTIVE.contains(player.getUuid()); }
    public static boolean isCombatMode(ServerPlayerEntity player) { return COMBAT_MODE.contains(player.getUuid()); }
    public static boolean isFaceplateOpen(ServerPlayerEntity player) { return FACEPLATE_OPEN.contains(player.getUuid()); }

    public static boolean hasArmorPiece(ServerPlayerEntity player, EquipmentSlot slot) {
        return ModItems.isArmorPiece(player.getEquippedStack(slot), slot);
    }

    private static boolean isAnyGauntlet(ItemStack stack) {
        return stack.isOf(ModItems.NANOTECH_GAUNTLET) || stack.isOf(ModItems.INFINITY_GAUNTLET);
    }

    private static boolean hasAnyGauntlet(ServerPlayerEntity player) {
        return isAnyGauntlet(player.getMainHandStack()) || isAnyGauntlet(player.getOffHandStack());
    }

    private static boolean hasInfinityGauntlet(ServerPlayerEntity player) {
        return player.getMainHandStack().isOf(ModItems.INFINITY_GAUNTLET)
                || player.getOffHandStack().isOf(ModItems.INFINITY_GAUNTLET);
    }

    private static boolean hasAnyComponent(ServerPlayerEntity player) {
        return hasArmorPiece(player, EquipmentSlot.HEAD)
                || hasArmorPiece(player, EquipmentSlot.CHEST)
                || hasArmorPiece(player, EquipmentSlot.LEGS)
                || hasArmorPiece(player, EquipmentSlot.FEET)
                || hasAnyGauntlet(player);
    }

    /** Pressing G materializes available Mark 112 armor, or retracts only pieces this system materialized. */
    public static void setActive(ServerPlayerEntity player, boolean active) {
        UUID id = player.getUuid();
        if (active) {
            materializeAvailableArmor(player);
            if (!hasAnyComponent(player)) {
                ACTIVE.remove(id);
                player.sendMessage(Text.literal("§b[JARVIS] §fNenhum componente Mark 112 detectado. Tenha uma peça equipada ou uma manopla na mão."), true);
                sync(player);
                return;
            }
            ACTIVE.add(id);
            emitMaterializeEffect(player);
            player.sendMessage(Text.literal("§b[JARVIS] §fSistemas Mark 112 ativados. Diagnóstico modular concluído."), true);
        } else {
            ACTIVE.remove(id);
            COMBAT_MODE.remove(id);
            removeFlight(player);
            retractModuleMaterializedArmor(player);
            emitRetractEffect(player);
            player.sendMessage(Text.literal("§b[JARVIS] §7Sistemas desligados. Componentes materializados recolhidos."), true);
        }
        sync(player);
    }

    private static void materializeAvailableArmor(ServerPlayerEntity player) {
        for (EquipmentSlot slot : armorSlots()) {
            if (!player.getEquippedStack(slot).isEmpty()) continue;
            ItemStack found = takeFirstArmorFromInventory(player, slot);
            if (!found.isEmpty()) {
                player.equipStack(slot, found);
                MATERIALIZED_SLOTS.computeIfAbsent(player.getUuid(), ignored -> new HashSet<>()).add(slot);
                if (slot == EquipmentSlot.HEAD) FACEPLATE_OPEN.remove(player.getUuid());
            }
        }
    }

    private static void retractModuleMaterializedArmor(ServerPlayerEntity player) {
        Set<EquipmentSlot> slots = MATERIALIZED_SLOTS.remove(player.getUuid());
        if (slots == null || slots.isEmpty()) return;
        for (EquipmentSlot slot : new ArrayList<>(slots)) {
            ItemStack worn = player.getEquippedStack(slot);
            if (ModItems.isArmorPiece(worn, slot)) {
                player.equipStack(slot, ItemStack.EMPTY);
                putInInventoryOrDrop(player, worn);
                if (slot == EquipmentSlot.HEAD) FACEPLATE_OPEN.add(player.getUuid());
            }
        }
    }

    private static ItemStack takeFirstArmorFromInventory(ServerPlayerEntity player, EquipmentSlot slot) {
        for (int i = 0; i < Math.min(36, player.getInventory().size()); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (ModItems.isArmorPiece(stack, slot)) return player.getInventory().removeStack(i, 1);
        }
        return ItemStack.EMPTY;
    }

    private static void putInInventoryOrDrop(ServerPlayerEntity player, ItemStack stack) {
        if (stack.isEmpty()) return;
        if (!player.getInventory().insertStack(stack)) player.dropItem(stack, false);
    }

    private static EquipmentSlot[] armorSlots() {
        return new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    }

    private static void togglePart(ServerPlayerEntity player, EquipmentSlot slot) {
        ItemStack worn = player.getEquippedStack(slot);
        if (ModItems.isArmorPiece(worn, slot)) {
            player.equipStack(slot, ItemStack.EMPTY);
            putInInventoryOrDrop(player, worn);
            Set<EquipmentSlot> tracked = MATERIALIZED_SLOTS.get(player.getUuid());
            if (tracked != null) {
                tracked.remove(slot);
                if (tracked.isEmpty()) MATERIALIZED_SLOTS.remove(player.getUuid());
            }
            if (slot == EquipmentSlot.HEAD) FACEPLATE_OPEN.add(player.getUuid());
            player.sendMessage(Text.literal("§b[JARVIS] §f" + partName(slot) + " recolhido em nanotecnologia."), true);
            emitRetractEffect(player);
        } else {
            if (!worn.isEmpty()) {
                player.sendMessage(Text.literal("§e[JARVIS] §fO espaço de " + partName(slot) + " está ocupado. Retire a peça atual primeiro."), true);
                return;
            }
            ItemStack found = takeFirstArmorFromInventory(player, slot);
            if (found.isEmpty()) {
                player.sendMessage(Text.literal("§e[JARVIS] §fNão encontrei " + partName(slot) + " no inventário."), true);
                return;
            }
            player.equipStack(slot, found);
            MATERIALIZED_SLOTS.computeIfAbsent(player.getUuid(), ignored -> new HashSet<>()).add(slot);
            if (slot == EquipmentSlot.HEAD) FACEPLATE_OPEN.remove(player.getUuid());
            ACTIVE.add(player.getUuid());
            player.sendMessage(Text.literal("§b[JARVIS] §f" + partName(slot) + " materializado."), true);
            emitMaterializeEffect(player);
        }
        if (!hasAnyComponent(player)) {
            ACTIVE.remove(player.getUuid());
            COMBAT_MODE.remove(player.getUuid());
            removeFlight(player);
        }
        sync(player);
    }

    private static String partName(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> "Capacete";
            case CHEST -> "Peitoral";
            case LEGS -> "Calças";
            case FEET -> "Botas";
            default -> "Componente";
        };
    }

    private static void toggleFaceplate(ServerPlayerEntity player) {
        ItemStack helmet = player.getEquippedStack(EquipmentSlot.HEAD);
        if (ModItems.isArmorPiece(helmet, EquipmentSlot.HEAD)) {
            togglePart(player, EquipmentSlot.HEAD);
            FACEPLATE_OPEN.add(player.getUuid());
            player.sendMessage(Text.literal("§b[JARVIS] §fFaceplate retraído. Rosto exposto."), true);
        } else {
            ItemStack fromInventory = takeFirstArmorFromInventory(player, EquipmentSlot.HEAD);
            if (fromInventory.isEmpty()) {
                FACEPLATE_OPEN.add(player.getUuid());
                player.sendMessage(Text.literal("§e[JARVIS] §fCapacete não encontrado. O rosto permanece exposto."), true);
            } else if (!helmet.isEmpty()) {
                putInInventoryOrDrop(player, fromInventory);
                player.sendMessage(Text.literal("§e[JARVIS] §fNão posso selar o capacete enquanto outro item ocupa o slot da cabeça."), true);
            } else {
                player.equipStack(EquipmentSlot.HEAD, fromInventory);
                MATERIALIZED_SLOTS.computeIfAbsent(player.getUuid(), ignored -> new HashSet<>()).add(EquipmentSlot.HEAD);
                FACEPLATE_OPEN.remove(player.getUuid());
                ACTIVE.add(player.getUuid());
                emitMaterializeEffect(player);
                player.sendMessage(Text.literal("§b[JARVIS] §fFaceplate reconstruído e selado."), true);
            }
        }
        sync(player);
    }

    public static void tick(ServerPlayerEntity player) {
        UUID id = player.getUuid();
        if (!ACTIVE.contains(id)) {
            if (FLIGHT_GRANTED.contains(id) && !player.isCreative() && !player.isSpectator()) removeFlight(player);
            tickCooldowns(player);
            return;
        }
        if (!hasAnyComponent(player)) {
            ACTIVE.remove(id);
            COMBAT_MODE.remove(id);
            removeFlight(player);
            retractModuleMaterializedArmor(player);
            sync(player);
            return;
        }

        boolean flightPartsPresent = hasArmorPiece(player, EquipmentSlot.CHEST) && hasArmorPiece(player, EquipmentSlot.FEET);
        if (flightPartsPresent && !player.isCreative() && !player.isSpectator()) {
            if (!player.getAbilities().allowFlying) {
                player.getAbilities().allowFlying = true;
                FLIGHT_GRANTED.add(id);
                player.sendAbilitiesUpdate();
            }
        } else {
            removeFlight(player);
        }

        if (player.age % 20 == 0) {
            if (hasArmorPiece(player, EquipmentSlot.HEAD) && !FACEPLATE_OPEN.contains(id)) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 45, 0, true, false, true));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 45, 0, true, false, true));
            }
            if (hasArmorPiece(player, EquipmentSlot.CHEST)) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 45, 0, true, false, true));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 45, 0, true, false, true));
            }
            if (hasArmorPiece(player, EquipmentSlot.LEGS)) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 45, 0, true, false, true));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 45, 0, true, false, true));
            }
            if (hasArmorPiece(player, EquipmentSlot.FEET)) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 45, 0, true, false, true));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 45, 0, true, false, true));
            }
            if (hasAnyGauntlet(player)) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 45, 0, true, false, true));
            }
        }
        if (player.age % 200 == 0) warnLowIntegrity(player);
        if (player.age % 1200 == 0) nanorepair(player);
        tickCooldowns(player);
        if (player.age % 20 == 0) sync(player);
    }

    private static void warnLowIntegrity(ServerPlayerEntity player) {
        for (EquipmentSlot slot : armorSlots()) {
            ItemStack stack = player.getEquippedStack(slot);
            if (!ModItems.isArmorPiece(stack, slot) || !stack.isDamageable()) continue;
            int max = stack.getMaxDamage();
            if (max <= 0) continue;
            int integrity = Math.max(0, (max - stack.getDamage()) * 100 / max);
            if (integrity <= 20) {
                player.sendMessage(Text.literal("§c[JARVIS ALERT] §f" + partName(slot) + " com apenas " + integrity + "% de integridade."), true);
            }
        }
    }

    private static void nanorepair(ServerPlayerEntity player) {
        boolean repaired = false;
        for (EquipmentSlot slot : armorSlots()) {
            ItemStack stack = player.getEquippedStack(slot);
            if (ModItems.isArmorPiece(stack, slot) && stack.isDamageable() && stack.getDamage() > 0) {
                stack.setDamage(stack.getDamage() - 1);
                repaired = true;
            }
        }
        if (repaired) {
            player.sendMessage(Text.literal("§b[JARVIS] §fNanorreparo: microdanos da blindagem corrigidos."), true);
            player.getServerWorld().spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(), 10, 0.35, 0.6, 0.35, 0.005);
        }
    }

    private static void tickCooldowns(ServerPlayerEntity player) {
        Map<Integer, Integer> perPlayer = COOLDOWNS.get(player.getUuid());
        if (perPlayer == null) return;
        perPlayer.replaceAll((action, until) -> until - 1);
        perPlayer.values().removeIf(until -> until <= 0);
        if (perPlayer.isEmpty()) COOLDOWNS.remove(player.getUuid());
    }

    private static void removeFlight(ServerPlayerEntity player) {
        UUID id = player.getUuid();
        if (!FLIGHT_GRANTED.contains(id) || player.isCreative() || player.isSpectator()) return;
        FLIGHT_GRANTED.remove(id);
        player.getAbilities().flying = false;
        player.getAbilities().allowFlying = false;
        player.sendAbilitiesUpdate();
    }

    public static void cleanup(ServerPlayerEntity player) {
        UUID id = player.getUuid();
        ACTIVE.remove(id);
        COMBAT_MODE.remove(id);
        FACEPLATE_OPEN.remove(id);
        MATERIALIZED_SLOTS.remove(id);
        COOLDOWNS.remove(id);
        FLIGHT_GRANTED.remove(id);
    }

    private static boolean onCooldown(ServerPlayerEntity player, int action, int ticks) {
        Map<Integer, Integer> perPlayer = COOLDOWNS.computeIfAbsent(player.getUuid(), ignored -> new HashMap<>());
        if (perPlayer.getOrDefault(action, 0) > 0) {
            player.sendMessage(Text.literal("§7[JARVIS] Sistema recarregando: " + (perPlayer.get(action) / 20 + 1) + "s."), true);
            return true;
        }
        perPlayer.put(action, ticks);
        return false;
    }

    public static void performAction(ServerPlayerEntity player, int action) {
        if (action >= 30 && action <= 35) {
            performInfinityAction(player, action);
            return;
        }
        switch (action) {
            case SuitActionPayload.REPULSOR -> fireRepulsor(player);
            case SuitActionPayload.SCAN -> scan(player);
            case SuitActionPayload.SHIELD -> shield(player);
            case SuitActionPayload.TOGGLE_COMBAT -> toggleCombatMode(player);
            case SuitActionPayload.ENERGY_BLADE -> energyBlade(player);
            case SuitActionPayload.FACEPLATE -> toggleFaceplate(player);
            case SuitActionPayload.TOGGLE_HELMET -> togglePart(player, EquipmentSlot.HEAD);
            case SuitActionPayload.TOGGLE_CHESTPLATE -> togglePart(player, EquipmentSlot.CHEST);
            case SuitActionPayload.TOGGLE_LEGGINGS -> togglePart(player, EquipmentSlot.LEGS);
            case SuitActionPayload.TOGGLE_BOOTS -> togglePart(player, EquipmentSlot.FEET);
            case SuitActionPayload.FABRICATE_KIT -> fabricateKit(player, 0);
            case SuitActionPayload.FABRICATE_BLACK_KIT -> fabricateKit(player, 1);
            case SuitActionPayload.FABRICATE_RED_KIT -> fabricateKit(player, 2);
            default -> { }
        }
    }

    private static void toggleCombatMode(ServerPlayerEntity player) {
        if (!ACTIVE.contains(player.getUuid())) {
            player.sendMessage(Text.literal("§e[JARVIS] §fMaterialize pelo menos um componente antes de ativar o modo de combate."), true);
            return;
        }
        if (COMBAT_MODE.remove(player.getUuid())) {
            player.sendMessage(Text.literal("§b[JARVIS] §fModo normal: armas recolhidas."), true);
        } else {
            COMBAT_MODE.add(player.getUuid());
            player.sendMessage(Text.literal("§c[JARVIS] §fModo de combate ativado."), true);
        }
        sync(player);
    }

    private static boolean requireActive(ServerPlayerEntity player) {
        if (!ACTIVE.contains(player.getUuid())) {
            player.sendMessage(Text.literal("§e[JARVIS] §fAtive a Mark 112 com G ou pela interface JARVIS."), true);
            return false;
        }
        return true;
    }

    private static void fireRepulsor(ServerPlayerEntity player) {
        if (!requireActive(player)) return;
        if (!COMBAT_MODE.contains(player.getUuid())) {
            player.sendMessage(Text.literal("§e[JARVIS] §fAtive o modo de combate com C primeiro."), true);
            return;
        }
        if (!hasAnyGauntlet(player)) {
            player.sendMessage(Text.literal("§e[JARVIS] §fMaterialize ou segure uma manopla para usar o repulsor."), true);
            return;
        }
        if (onCooldown(player, 1, 12)) return;
        Vec3d direction = player.getRotationVector().normalize();
        SmallFireballEntity shot = new SmallFireballEntity(player.getWorld(), player, direction.x, direction.y, direction.z);
        shot.setPosition(player.getX() + direction.x * 1.2, player.getEyeY() + direction.y * 1.2, player.getZ() + direction.z * 1.2);
        player.getWorld().spawnEntity(shot);
        player.getServerWorld().spawnParticles(ParticleTypes.END_ROD, player.getX() + direction.x, player.getEyeY() + direction.y, player.getZ() + direction.z, 8, 0.1, 0.1, 0.1, 0.01);
    }

    private static void scan(ServerPlayerEntity player) {
        if (!requireActive(player)) return;
        if (!hasArmorPiece(player, EquipmentSlot.HEAD) || FACEPLATE_OPEN.contains(player.getUuid())) {
            player.sendMessage(Text.literal("§e[JARVIS] §fO scanner exige capacete selado."), true);
            return;
        }
        if (onCooldown(player, 2, 100)) return;
        int count = 0;
        for (Entity entity : player.getWorld().getOtherEntities(player, player.getBoundingBox().expand(28))) {
            if (entity instanceof LivingEntity living && living.isAlive() && !living.isSpectator()) {
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 80, 0, true, false, true), player);
                count++;
            }
        }
        player.sendMessage(Text.literal("§b[JARVIS SCAN] §fEntidades detectadas: " + count), true);
    }

    private static void shield(ServerPlayerEntity player) {
        if (!requireActive(player)) return;
        if (!hasArmorPiece(player, EquipmentSlot.CHEST)) {
            player.sendMessage(Text.literal("§e[JARVIS] §fO escudo de emergência exige o peitoral materializado."), true);
            return;
        }
        if (onCooldown(player, 3, 200)) return;
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 3, true, false, true));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 60, 2, true, false, true));
        player.getServerWorld().spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(), 35, 0.8, 0.8, 0.8, 0.03);
        player.sendMessage(Text.literal("§b[JARVIS] §fEscudo de emergência: 3 segundos."), true);
    }

    private static void energyBlade(ServerPlayerEntity player) {
        if (!requireActive(player)) return;
        if (!COMBAT_MODE.contains(player.getUuid())) {
            player.sendMessage(Text.literal("§e[JARVIS] §fAtive o modo de combate com C primeiro."), true);
            return;
        }
        if (!hasAnyGauntlet(player)) {
            player.sendMessage(Text.literal("§e[JARVIS] §fSegure uma manopla para materializar a lâmina."), true);
            return;
        }
        if (onCooldown(player, 5, 12)) return;
        Vec3d look = player.getRotationVector().normalize();
        var box = player.getBoundingBox().expand(3.2, 2.0, 3.2);
        int hits = 0;
        for (Entity entity : player.getWorld().getOtherEntities(player, box)) {
            if (entity instanceof LivingEntity target && target.isAlive() && !target.isSpectator()) {
                Vec3d toTarget = target.getBoundingBox().getCenter().subtract(player.getEyePos()).normalize();
                if (look.dotProduct(toTarget) > 0.35 && player.getEyePos().squaredDistanceTo(target.getBoundingBox().getCenter()) <= 10.24) {
                    target.damage(player.getDamageSources().playerAttack(player), 10.0F);
                    target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 30, 0, true, false, true), player);
                    hits++;
                }
            }
        }
        player.sendMessage(Text.literal("§b[JARVIS] §fLâmina de energia: " + hits + " alvo(s)."), true);
    }

    private static void fabricateKit(ServerPlayerEntity player, int style) {
        String styleName = switch (style) { case 1 -> "Tático Preto"; case 2 -> "Vermelho Dourado"; default -> "Branco Dourado"; };
        ItemStack[] kit = new ItemStack[]{
                new ItemStack(ModItems.armorItemForStyle(EquipmentSlot.HEAD, style)),
                new ItemStack(ModItems.armorItemForStyle(EquipmentSlot.CHEST, style)),
                new ItemStack(ModItems.armorItemForStyle(EquipmentSlot.LEGS, style)),
                new ItemStack(ModItems.armorItemForStyle(EquipmentSlot.FEET, style)),
                new ItemStack(ModItems.NANOTECH_GAUNTLET),
                new ItemStack(ModItems.INFINITY_GAUNTLET),
                new ItemStack(ModItems.JARVIS_CORE)
        };
        for (ItemStack stack : kit) putInInventoryOrDrop(player, stack);
        player.sendMessage(Text.literal("§b[JARVIS FABRICATOR] §fKit " + styleName + " fabricado."), false);
    }

    private static void performInfinityAction(ServerPlayerEntity player, int action) {
        if (!hasInfinityGauntlet(player)) {
            player.sendMessage(Text.literal("§e[JARVIS] §fSegure a Manopla do Infinito na mão principal ou secundária."), true);
            return;
        }
        if (onCooldown(player, action, action == SuitActionPayload.INFINITY_POWER ? 100 : 160)) return;
        switch (action) {
            case SuitActionPayload.INFINITY_POWER -> {
                int hit = 0;
                for (Entity entity : player.getWorld().getOtherEntities(player, player.getBoundingBox().expand(5.0))) {
                    if (entity instanceof LivingEntity living && living.isAlive() && !living.isSpectator()) {
                        living.damage(player.getDamageSources().playerAttack(player), 12.0F);
                        hit++;
                    }
                }
                player.getServerWorld().spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 60, 1.0, 1.0, 1.0, 0.2);
                player.sendMessage(Text.literal("§5[JOIA DO PODER] §fPulso de energia liberado. Alvos atingidos: " + hit), true);
            }
            case SuitActionPayload.INFINITY_REALITY -> {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 100, 0, true, false, true));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 100, 1, true, false, true));
                player.getServerWorld().spawnParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1, player.getZ(), 55, 0.7, 0.9, 0.7, 0.08);
                player.sendMessage(Text.literal("§c[JOIA DA REALIDADE] §fDistorção defensiva ativada por 5 segundos."), true);
            }
            case SuitActionPayload.INFINITY_SOUL -> {
                int count = markNearby(player, StatusEffects.GLOWING, 160, 0);
                player.getServerWorld().spawnParticles(ParticleTypes.SOUL, player.getX(), player.getY() + 1, player.getZ(), 35, 0.8, 0.8, 0.8, 0.03);
                player.sendMessage(Text.literal("§6[JOIA DA ALMA] §fPresenças detectadas: " + count), true);
            }
            case SuitActionPayload.INFINITY_TIME -> {
                int count = markNearby(player, StatusEffects.SLOWNESS, 100, 2);
                markNearby(player, StatusEffects.WEAKNESS, 100, 0);
                player.getServerWorld().spawnParticles(ParticleTypes.WAX_ON, player.getX(), player.getY() + 1, player.getZ(), 40, 0.8, 0.8, 0.8, 0.02);
                player.sendMessage(Text.literal("§a[JOIA DO TEMPO] §fMovimento de " + count + " entidade(s) desacelerado."), true);
            }
            case SuitActionPayload.INFINITY_MIND -> {
                int count = markNearby(player, StatusEffects.GLOWING, 120, 0);
                markNearby(player, StatusEffects.WEAKNESS, 120, 1);
                player.getServerWorld().spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getEyeY(), player.getZ(), 30, 0.5, 0.4, 0.5, 0.04);
                player.sendMessage(Text.literal("§e[JOIA DA MENTE] §fLink mental estabelecido com " + count + " entidade(s)."), true);
            }
            default -> { }
        }
    }

    private static int markNearby(ServerPlayerEntity player, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effect, int duration, int amplifier) {
        int count = 0;
        for (Entity entity : player.getWorld().getOtherEntities(player, player.getBoundingBox().expand(12.0))) {
            if (entity instanceof LivingEntity living && living.isAlive() && !living.isSpectator()) {
                living.addStatusEffect(new StatusEffectInstance(effect, duration, amplifier, true, false, true), player);
                count++;
            }
        }
        return count;
    }

    public static void openCoordinatePortal(ServerPlayerEntity player, PortalPayload payload) {
        if (!ACTIVE.contains(player.getUuid())) {
            player.sendMessage(Text.literal("§e[JARVIS PORTAL] §fAtive a Mark 112 primeiro."), true);
            return;
        }
        if (Math.abs((long) payload.x()) > 29_999_984L || Math.abs((long) payload.z()) > 29_999_984L) {
            player.sendMessage(Text.literal("§c[JARVIS PORTAL] §fCoordenadas fora dos limites do mundo."), true);
            return;
        }
        Identifier dimensionId = Identifier.tryParse(payload.dimension());
        if (dimensionId == null) {
            player.sendMessage(Text.literal("§c[JARVIS PORTAL] §fDimensão inválida."), true);
            return;
        }
        MinecraftServer server = player.getServer();
        if (server == null) return;
        RegistryKey<World> key = RegistryKey.of(RegistryKeys.WORLD, dimensionId);
        ServerWorld targetWorld = server.getWorld(key);
        if (targetWorld == null) {
            player.sendMessage(Text.literal("§c[JARVIS PORTAL] §fEssa dimensão não está carregada ou não existe."), true);
            return;
        }
        if (payload.y() < targetWorld.getBottomY() + 1 || payload.y() >= targetWorld.getTopY() - 1) {
            player.sendMessage(Text.literal("§c[JARVIS PORTAL] §fCoordenada Y fora da altura permitida."), true);
            return;
        }
        BlockPos feet = new BlockPos(payload.x(), payload.y(), payload.z());
        BlockPos head = feet.up();
        BlockPos floor = feet.down();
        boolean safe = targetWorld.getBlockState(feet).isAir()
                && targetWorld.getBlockState(head).isAir()
                && targetWorld.getBlockState(floor).isSolidBlock(targetWorld, floor);
        if (!safe) {
            player.sendMessage(Text.literal("§e[JARVIS PORTAL] §fDestino bloqueado ou sem chão seguro. Escolha coordenadas com dois blocos de espaço e piso sólido."), true);
            return;
        }
        player.getServerWorld().spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 70, 0.6, 1.0, 0.6, 0.12);
        targetWorld.spawnParticles(ParticleTypes.END_ROD, payload.x() + 0.5, payload.y() + 0.5, payload.z() + 0.5, 45, 0.4, 0.6, 0.4, 0.035);
        player.teleport(targetWorld, payload.x() + 0.5, payload.y(), payload.z() + 0.5, Set.of(), player.getYaw(), player.getPitch());
        targetWorld.spawnParticles(ParticleTypes.PORTAL, payload.x() + 0.5, payload.y() + 1.0, payload.z() + 0.5, 70, 0.6, 1.0, 0.6, 0.12);
        player.sendMessage(Text.literal("§b[JARVIS PORTAL] §fTransferência concluída para " + payload.dimension() + " §7(" + payload.x() + ", " + payload.y() + ", " + payload.z() + ")"), true);
    }

    private static void emitMaterializeEffect(ServerPlayerEntity player) {
        player.getServerWorld().spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(), 35, 0.55, 0.9, 0.55, 0.035);
        player.getServerWorld().spawnParticles(ParticleTypes.CRIT, player.getX(), player.getY() + 1.0, player.getZ(), 18, 0.45, 0.8, 0.45, 0.02);
    }

    private static void emitRetractEffect(ServerPlayerEntity player) {
        player.getServerWorld().spawnParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1.0, player.getZ(), 28, 0.6, 0.8, 0.6, 0.06);
    }

    public static void sync(ServerPlayerEntity player) {
        ServerPlayNetworking.send(player, new SuitStatePayload(
                ACTIVE.contains(player.getUuid()),
                COMBAT_MODE.contains(player.getUuid()),
                FACEPLATE_OPEN.contains(player.getUuid())
        ));
    }
}
