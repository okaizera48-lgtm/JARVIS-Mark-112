package br.jarvis.mark112;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

public final class ModItems {
    private ModItems() {}

    // Three actual texture/asset presets: white-gold, tactical black, and red-gold.
    public static final Item NANOTECH_HELMET = registerArmor("nanotech_helmet", EquipmentSlot.HEAD, 3, 407, "nanotech");
    public static final Item NANOTECH_CHESTPLATE = registerArmor("nanotech_chestplate", EquipmentSlot.CHEST, 8, 592, "nanotech");
    public static final Item NANOTECH_LEGGINGS = registerArmor("nanotech_leggings", EquipmentSlot.LEGS, 6, 555, "nanotech");
    public static final Item NANOTECH_BOOTS = registerArmor("nanotech_boots", EquipmentSlot.FEET, 3, 481, "nanotech");

    public static final Item BLACK_HELMET = registerArmor("nanotech_black_helmet", EquipmentSlot.HEAD, 3, 407, "nanotech_black");
    public static final Item BLACK_CHESTPLATE = registerArmor("nanotech_black_chestplate", EquipmentSlot.CHEST, 8, 592, "nanotech_black");
    public static final Item BLACK_LEGGINGS = registerArmor("nanotech_black_leggings", EquipmentSlot.LEGS, 6, 555, "nanotech_black");
    public static final Item BLACK_BOOTS = registerArmor("nanotech_black_boots", EquipmentSlot.FEET, 3, 481, "nanotech_black");

    public static final Item RED_HELMET = registerArmor("nanotech_red_helmet", EquipmentSlot.HEAD, 3, 407, "nanotech_red");
    public static final Item RED_CHESTPLATE = registerArmor("nanotech_red_chestplate", EquipmentSlot.CHEST, 8, 592, "nanotech_red");
    public static final Item RED_LEGGINGS = registerArmor("nanotech_red_leggings", EquipmentSlot.LEGS, 6, 555, "nanotech_red");
    public static final Item RED_BOOTS = registerArmor("nanotech_red_boots", EquipmentSlot.FEET, 3, 481, "nanotech_red");

    /** Hold this item in either hand to use the Mark 112 hand systems. */
    public static final Item NANOTECH_GAUNTLET = registerSimple("nanotech_gauntlet", 1);
    /** Six-stone gauntlet. Its powers are activated through the JARVIS interface. */
    public static final Item INFINITY_GAUNTLET = registerSimple("infinity_gauntlet", 1);
    /** A handheld JARVIS focus item; the J key also opens the interface. */
    public static final Item JARVIS_CORE = registerSimple("jarvis_core", 1);

    public static Item armorItemForStyle(EquipmentSlot slot, int style) {
        return switch (style) {
            case 1 -> switch (slot) {
                case HEAD -> BLACK_HELMET;
                case CHEST -> BLACK_CHESTPLATE;
                case LEGS -> BLACK_LEGGINGS;
                case FEET -> BLACK_BOOTS;
                default -> null;
            };
            case 2 -> switch (slot) {
                case HEAD -> RED_HELMET;
                case CHEST -> RED_CHESTPLATE;
                case LEGS -> RED_LEGGINGS;
                case FEET -> RED_BOOTS;
                default -> null;
            };
            default -> switch (slot) {
                case HEAD -> NANOTECH_HELMET;
                case CHEST -> NANOTECH_CHESTPLATE;
                case LEGS -> NANOTECH_LEGGINGS;
                case FEET -> NANOTECH_BOOTS;
                default -> null;
            };
        };
    }

    public static boolean isArmorPiece(ItemStack stack, EquipmentSlot slot) {
        return !stack.isEmpty() && (stack.isOf(armorItemForStyle(slot, 0))
                || stack.isOf(armorItemForStyle(slot, 1)) || stack.isOf(armorItemForStyle(slot, 2)));
    }

    private static Item registerSimple(String name, int maxCount) {
        return Registry.register(Registries.ITEM,
                Identifier.of(Mark112Nanotech.MOD_ID, name),
                new Item(new Item.Settings().maxCount(maxCount)));
    }

    private static Item registerArmor(String name, EquipmentSlot slot, int armor, int durability, String asset) {
        Identifier id = Identifier.of(Mark112Nanotech.MOD_ID, name);
        Identifier modifierId = Identifier.of(Mark112Nanotech.MOD_ID, name + "_armor");
        var slotGroup = switch (slot) {
            case HEAD -> net.minecraft.entity.EquipmentSlotGroup.HEAD;
            case CHEST -> net.minecraft.entity.EquipmentSlotGroup.CHEST;
            case LEGS -> net.minecraft.entity.EquipmentSlotGroup.LEGS;
            case FEET -> net.minecraft.entity.EquipmentSlotGroup.FEET;
            default -> net.minecraft.entity.EquipmentSlotGroup.ANY;
        };
        var attributes = net.minecraft.component.type.ItemAttributeModifiers.builder()
                .add(EntityAttributes.ARMOR,
                        new EntityAttributeModifier(modifierId, armor, EntityAttributeModifier.Operation.ADD_VALUE), slotGroup)
                .add(EntityAttributes.ARMOR_TOUGHNESS,
                        new EntityAttributeModifier(Identifier.of(Mark112Nanotech.MOD_ID, name + "_toughness"), 3.0, EntityAttributeModifier.Operation.ADD_VALUE), slotGroup)
                .build();
        var equip = EquippableComponent.builder(slot)
                .equipSound(SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE)
                .assetId(Identifier.of(Mark112Nanotech.MOD_ID, asset))
                .build();
        Item item = new Item(new Item.Settings()
                .maxCount(1)
                .maxDamage(durability)
                .component(DataComponentTypes.EQUIPPABLE, equip)
                .attributeModifiers(attributes));
        return Registry.register(Registries.ITEM, id, item);
    }

    public static void register() {
        // Loading this class registers all custom items.
    }
}
