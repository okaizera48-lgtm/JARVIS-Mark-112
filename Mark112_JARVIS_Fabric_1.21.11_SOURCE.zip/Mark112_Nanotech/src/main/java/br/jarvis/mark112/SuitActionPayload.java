package br.jarvis.mark112;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record SuitActionPayload(int action) implements CustomPayload {
    public static final int REPULSOR = 1;
    public static final int SCAN = 2;
    public static final int SHIELD = 3;
    public static final int TOGGLE_COMBAT = 4;
    public static final int ENERGY_BLADE = 5;
    public static final int FACEPLATE = 6;
    public static final int TOGGLE_HELMET = 10;
    public static final int TOGGLE_CHESTPLATE = 11;
    public static final int TOGGLE_LEGGINGS = 12;
    public static final int TOGGLE_BOOTS = 13;
    public static final int FABRICATE_KIT = 15;
    public static final int FABRICATE_BLACK_KIT = 16;
    public static final int FABRICATE_RED_KIT = 17;
    public static final int INFINITY_POWER = 30;
    public static final int INFINITY_REALITY = 32;
    public static final int INFINITY_SOUL = 33;
    public static final int INFINITY_TIME = 34;
    public static final int INFINITY_MIND = 35;

    public static final Id<SuitActionPayload> ID = new Id<>(Identifier.of(Mark112Nanotech.MOD_ID, "suit_action"));
    public static final PacketCodec<RegistryByteBuf, SuitActionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, SuitActionPayload::action,
            SuitActionPayload::new
    );

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
