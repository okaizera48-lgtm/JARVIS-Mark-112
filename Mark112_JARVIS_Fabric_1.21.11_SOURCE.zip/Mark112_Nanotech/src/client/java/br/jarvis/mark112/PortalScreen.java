package br.jarvis.mark112;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Coordinate portal panel with integer fields, dimension cycling, and server-side destination validation. */
public final class PortalScreen extends Screen {
    private final Screen parent;
    private final String[] fields = {"0", "80", "0"};
    private int focused = 0;
    private String dimension = "minecraft:overworld";
    private int panelX, panelY, panelW, panelH;
    private int fieldX, fieldY, fieldW, fieldH;

    public PortalScreen(Screen parent) {
        super(Text.literal("JARVIS Coordinate Portal"));
        this.parent = parent;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            fields[0] = Integer.toString(client.player.getBlockX() + 5);
            fields[1] = Integer.toString(client.player.getBlockY());
            fields[2] = Integer.toString(client.player.getBlockZ() + 5);
            if (client.player.getWorld() != null) dimension = client.player.getWorld().getRegistryKey().getValue().toString();
        }
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xD807111C);
        panelW = Math.min(330, width - 20);
        panelH = 225;
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF00A1724);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFF35C9F5);
        context.fill(panelX, panelY + panelH - 2, panelX + panelW, panelY + panelH, 0xFF1F88B2);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("J.A.R.V.I.S. // COORDINATE PORTAL"), width / 2, panelY + 12, 0xFF75E4FF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Escolha um destino com piso sólido e dois blocos livres."), width / 2, panelY + 29, 0xFFB6D9EA);

        int labelY = panelY + 57;
        context.drawTextWithShadow(textRenderer, Text.literal("X"), panelX + 26, labelY, 0xFFB6D9EA);
        context.drawTextWithShadow(textRenderer, Text.literal("Y"), panelX + 26, labelY + 37, 0xFFB6D9EA);
        context.drawTextWithShadow(textRenderer, Text.literal("Z"), panelX + 26, labelY + 74, 0xFFB6D9EA);
        fieldX = panelX + 48;
        fieldW = panelW - 72;
        fieldH = 24;
        fieldY = labelY - 5;
        for (int i = 0; i < 3; i++) {
            int fy = fieldY + i * 37;
            boolean selected = focused == i;
            context.fill(fieldX, fy, fieldX + fieldW, fy + fieldH, 0xFF0C2332);
            context.fill(fieldX, fy, fieldX + fieldW, fy + 1, selected ? 0xFF8AF0FF : 0xFF267C9B);
            context.fill(fieldX, fy + fieldH - 1, fieldX + fieldW, fy + fieldH, selected ? 0xFF8AF0FF : 0xFF267C9B);
            context.drawTextWithShadow(textRenderer, Text.literal(fields[i] + (selected ? "_" : "")), fieldX + 8, fy + 8, 0xFFEAFBFF);
        }
        int dimY = fieldY + 119;
        drawButton(context, panelX + 20, dimY, panelW - 40, 22, "DIMENSÃO: " + dimension + "  (clique para alternar)", mouseX, mouseY);
        int btnY = dimY + 31;
        drawButton(context, panelX + 20, btnY, (panelW - 46) / 2, 23, "ABRIR PORTAL", mouseX, mouseY);
        drawButton(context, panelX + 26 + (panelW - 46) / 2, btnY, (panelW - 46) / 2, 23, "VOLTAR", mouseX, mouseY);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawButton(DrawContext ctx, int x, int y, int w, int h, String label, int mx, int my) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
        ctx.fill(x, y, x + w, y + h, hover ? 0xFF175070 : 0xE7132B3B);
        ctx.fill(x, y, x + w, y + 1, hover ? 0xFF8AF0FF : 0xFF267C9B);
        ctx.fill(x, y + h - 1, x + w, y + h, 0xFF267C9B);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(label), x + w / 2, y + (h - 8) / 2, 0xFFEAFBFF);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (mx >= fieldX && mx < fieldX + fieldW) {
            for (int i = 0; i < 3; i++) {
                int fy = fieldY + i * 37;
                if (my >= fy && my < fy + fieldH) { focused = i; return true; }
            }
        }
        int dimY = fieldY + 119;
        if (mx >= panelX + 20 && mx < panelX + panelW - 20 && my >= dimY && my < dimY + 22) {
            dimension = switch (dimension) {
                case "minecraft:overworld" -> "minecraft:the_nether";
                case "minecraft:the_nether" -> "minecraft:the_end";
                default -> "minecraft:overworld";
            };
            return true;
        }
        int btnY = dimY + 31;
        if (my >= btnY && my < btnY + 23) {
            int split = panelX + 20 + (panelW - 46) / 2;
            if (mx >= panelX + 20 && mx < split) submitPortal();
            else if (mx >= split + 6 && mx < panelX + panelW - 20) MinecraftClient.getInstance().setScreen(parent);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void submitPortal() {
        try {
            int x = Integer.parseInt(fields[0]);
            int y = Integer.parseInt(fields[1]);
            int z = Integer.parseInt(fields[2]);
            ClientPlayNetworking.send(new PortalPayload(x, y, z, dimension));
            MinecraftClient.getInstance().setScreen(parent);
        } catch (NumberFormatException ex) {
            fields[0] = fields[0].isBlank() ? "0" : fields[0];
            MinecraftClient.getInstance().player.sendMessage(Text.literal("§e[JARVIS] Digite números inteiros válidos para X, Y e Z."), true);
        }
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (focused < 0 || focused >= fields.length) return super.charTyped(chr, modifiers);
        if ((chr >= '0' && chr <= '9') || (chr == '-' && fields[focused].isEmpty())) {
            if (fields[focused].length() < 10) fields[focused] += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { MinecraftClient.getInstance().setScreen(parent); return true; }
        if (keyCode == GLFW.GLFW_KEY_TAB) { focused = (focused + 1) % 3; return true; }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { submitPortal(); return true; }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && focused >= 0 && focused < 3) {
            if (!fields[focused].isEmpty()) fields[focused] = fields[focused].substring(0, fields[focused].length() - 1);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
