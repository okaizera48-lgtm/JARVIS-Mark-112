package br.jarvis.mark112;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Blocky Minecraft-style control panel for the six-stone Infinity Gauntlet prototype. */
public final class InfinityScreen extends Screen {
    private final Screen parent;
    private final List<Button> buttons = new ArrayList<>();
    private int panelX, panelY, panelW, panelH;

    public InfinityScreen(Screen parent) {
        super(Text.literal("Manopla do Infinito"));
        this.parent = parent;
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xD807111C);
        panelW = Math.min(370, width - 20);
        panelH = Math.min(255, height - 20);
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF00A1724);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFFB18AFF);
        context.fill(panelX, panelY + panelH - 2, panelX + panelW, panelY + panelH, 0xFF7656B8);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("INFINITY GAUNTLET"), width / 2, panelY + 12, 0xFFDCC7FF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Segure a Manopla do Infinito em uma das mãos"), width / 2, panelY + 28, 0xFFBEB3D7);
        String[][] specs = {
                {"JOIA DO PODER", "30"}, {"JOIA DO ESPAÇO / PORTAL", "-1"},
                {"JOIA DA REALIDADE", "32"}, {"JOIA DA ALMA", "33"},
                {"JOIA DO TEMPO", "34"}, {"JOIA DA MENTE", "35"},
                {"VOLTAR AO JARVIS", "-2"}
        };
        buttons.clear();
        int gap = 6;
        int bx = panelX + 14;
        int by = panelY + 52;
        int bw = (panelW - 28 - gap) / 2;
        int bh = 24;
        for (int i = 0; i < specs.length; i++) {
            int col = i % 2;
            int row = i / 2;
            int x = bx + col * (bw + gap);
            int y = by + row * (bh + 6);
            Button b = new Button(x, y, bw, bh, specs[i][0], Integer.parseInt(specs[i][1]));
            buttons.add(b);
            drawButton(context, b, mouseX, mouseY);
        }
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Efeitos simulados no Minecraft; recargas por joia."), width / 2, panelY + panelH - 15, 0xFF9EBBD0);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawButton(DrawContext ctx, Button b, int mx, int my) {
        boolean hover = mx >= b.x && mx < b.x + b.w && my >= b.y && my < b.y + b.h;
        ctx.fill(b.x, b.y, b.x + b.w, b.y + b.h, hover ? 0xFF342B5A : 0xE71B203A);
        ctx.fill(b.x, b.y, b.x + b.w, b.y + 1, hover ? 0xFFE5CFFF : 0xFF8A76BC);
        ctx.fill(b.x, b.y + b.h - 1, b.x + b.w, b.y + b.h, 0xFF8A76BC);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(b.label), b.x + b.w / 2, b.y + 8, 0xFFF2E8FF);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        for (Button b : buttons) {
            if (mx >= b.x && mx < b.x + b.w && my >= b.y && my < b.y + b.h) {
                if (b.action == -2) MinecraftClient.getInstance().setScreen(parent);
                else if (b.action == -1) MinecraftClient.getInstance().setScreen(new PortalScreen(this));
                else ClientPlayNetworking.send(new SuitActionPayload(b.action));
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { MinecraftClient.getInstance().setScreen(parent); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private record Button(int x, int y, int w, int h, String label, int action) {}
}
