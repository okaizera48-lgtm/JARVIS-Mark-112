package br.jarvis.mark112;

/** Client mirror of the authoritative state sent by the integrated/dedicated server. */
public final class ClientState {
    public static boolean active = false;
    public static boolean combatMode = false;
    public static boolean faceplateOpen = false;

    private ClientState() {}
}
