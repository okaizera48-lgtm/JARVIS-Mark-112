package br.jarvis.mark112;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class Mark112NanotechClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static KeyBinding jarvisKey;
    private static KeyBinding repulsorKey;
    private static KeyBinding scanKey;
    private static KeyBinding shieldKey;
    private static KeyBinding combatModeKey;
    private static KeyBinding bladeKey;
    private static KeyBinding faceplateKey;

    @Override
    public void onInitializeClient() {
        toggleKey = register("toggle", GLFW.GLFW_KEY_G);
        jarvisKey = register("jarvis_panel", GLFW.GLFW_KEY_J);
        repulsorKey = register("repulsor", GLFW.GLFW_KEY_R);
        scanKey = register("scan", GLFW.GLFW_KEY_V);
        shieldKey = register("shield", GLFW.GLFW_KEY_B);
        combatModeKey = register("combat_mode", GLFW.GLFW_KEY_C);
        bladeKey = register("energy_blade", GLFW.GLFW_KEY_X);
        faceplateKey = register("faceplate", GLFW.GLFW_KEY_H);

        ClientPlayNetworking.registerGlobalReceiver(SuitStatePayload.ID, (payload, context) -> context.client().execute(() -> {
            ClientState.active = payload.active();
            ClientState.combatMode = payload.combatMode();
            ClientState.faceplateOpen = payload.faceplateOpen();
        }));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (toggleKey.wasPressed()) {
                ClientState.active = !ClientState.active;
                ClientPlayNetworking.send(new ToggleSuitPayload(ClientState.active));
            }
            while (jarvisKey.wasPressed()) client.setScreen(new JarvisScreen());
            if (repulsorKey.wasPressed() && ClientState.active) ClientPlayNetworking.send(new SuitActionPayload(SuitActionPayload.REPULSOR));
            if (scanKey.wasPressed() && ClientState.active) ClientPlayNetworking.send(new SuitActionPayload(SuitActionPayload.SCAN));
            if (shieldKey.wasPressed() && ClientState.active) ClientPlayNetworking.send(new SuitActionPayload(SuitActionPayload.SHIELD));
            if (combatModeKey.wasPressed() && ClientState.active) ClientPlayNetworking.send(new SuitActionPayload(SuitActionPayload.TOGGLE_COMBAT));
            if (bladeKey.wasPressed() && ClientState.active) ClientPlayNetworking.send(new SuitActionPayload(SuitActionPayload.ENERGY_BLADE));
            if (faceplateKey.wasPressed()) ClientPlayNetworking.send(new SuitActionPayload(SuitActionPayload.FACEPLATE));
        });
    }

    private KeyBinding register(String suffix, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mark112_nanotech." + suffix,
                InputUtil.Type.KEYSYM,
                key,
                "category.mark112_nanotech"
        ));
    }
}
