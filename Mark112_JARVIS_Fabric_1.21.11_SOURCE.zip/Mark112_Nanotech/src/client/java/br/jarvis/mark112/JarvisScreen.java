package br.jarvis.mark112;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** A lightweight, touch-friendly holographic JARVIS panel made from Minecraft GUI primitives. */
public final class JarvisScreen extends Screen {
    private static final int ACTION_TOGGLE_ACTIVE = -1;
    private static final int ACTION_OPEN_INFINITY = -2;
    private static final int ACTION_OPEN_PORTAL = -3;
    private final List<UiButton> buttons = new ArrayList<>();
    private int panelX, panelY, panelW, panelH;

    public JarvisScreen() {
        super(Text.literal("J.A.R.V.I.S. — Mark 112"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xD807111C);
        panelW = Math.min(430, width - 18);
        panelH = Math.min(350, height - 16);
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        drawPanel(context, panelX, panelY, panelW, panelH);

        context.drawCenteredTextWithShadow(textRenderer, Text.literal("J.A.R.V.I.S."), width / 2, panelY + 10, 0xFF75E4FF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("MARK 112  //  NANOTECH CONTROL SYSTEM"), width / 2, panelY + 25, 0xFFB6D9EA);
        context.drawTextWithShadow(textRenderer, Text.literal("SISTEMAS: " + (ClientState.active ? "ATIVOS" : "EM ESPERA")), panelX + 14, panelY + 44, ClientState.active ? 0xFF74F0D0 : 0xFFFFD37A);
        context.drawTextWithShadow(textRenderer, Text.literal("COMBATE: " + (ClientState.combatMode ? "ATIVO" : "NORMAL")), panelX + 14, panelY + 56, ClientState.combatMode ? 0xFFFF7777 : 0xFFB7D4E8);
        drawEquipmentStatus(context, panelX + panelW / 2 + 6, panelY + 43);

        buttons.clear();
        String[][] specs = {
                {"MATERIALIZAR / RECOLHER", Integer.toString(ACTION_TOGGLE_ACTIVE)}, {ClientState.combatMode ? "MODO NORMAL" : "MODO COMBATE", "4"},
                {"CAPACETE", "10"}, {"PEITORAL", "11"},
                {"CALÇAS", "12"}, {"BOTAS", "13"},
                {"REPULSOR", "1"}, {"SCANNER", "2"},
                {"ESCUDO DE EMERGÊNCIA", "3"}, {"LÂMINA DE ENERGIA", "5"},
                {ClientState.faceplateOpen ? "SELAR CAPACETE" : "ABRIR FACEPLATE", "6"}, {"FABRICAR BRANCO/DOURADO", "15"},
                {"FABRICAR PRETO TÁTICO", "16"}, {"FABRICAR VERMELHO", "17"},
                {"JOIAS DO INFINITO", Integer.toString(ACTION_OPEN_INFINITY)}, {"PORTAL POR COORDENADAS", Integer.toString(ACTION_OPEN_PORTAL)}
        };
        int x = panelX + 14;
        int y = panelY + 98;
        int gap = 6;
        int buttonW = (panelW - 28 - gap) / 2;
        int buttonH = panelH < 310 ? 17 : 21;
        int stride = buttonH + 4;
        for (int i = 0; i < specs.length; i++) {
            int col = i % 2;
            int row = i / 2;
            int bx = x + col * (buttonW + gap);
            int by = y + row * stride;
            UiButton button = new UiButton(bx, by, buttonW, buttonH, specs[i][0], Integer.parseInt(specs[i][1]));
            buttons.add(button);
            drawButton(context, button, mouseX, mouseY);
        }
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("G: traje  •  J: JARVIS  •  C/R/V/B/X: combate e sistemas"), width / 2, panelY + panelH - 13, 0xFF8CB8CD);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawEquipmentStatus(DrawContext context, int x, int y) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        context.drawTextWithShadow(textRenderer, Text.literal("MÓDULOS / INTEGRIDADE"), x, y - 2, 0xFF75E4FF);
        int dy = 11;
        drawPartStatus(context, x, y + dy, "CAPACETE", EquipmentSlot.HEAD);
        drawPartStatus(context, x, y + dy * 2, "PEITORAL", EquipmentSlot.CHEST);
        drawPartStatus(context, x, y + dy * 3, "CALÇAS", EquipmentSlot.LEGS);
        drawPartStatus(context, x, y + dy * 4, "BOTAS", EquipmentSlot.FEET);
    }

    private void drawPartStatus(DrawContext context, int x, int y, String name, EquipmentSlot slot) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        net.minecraft.item.ItemStack stack = client.player.getEquippedStack(slot);
        if (!ModItems.isArmorPiece(stack, slot)) {
            context.drawTextWithShadow(textRenderer, Text.literal(name + ": --"), x, y, 0xFF7F9EAF);
            return;
        }
        int percent = stack.isDamageable() && stack.getMaxDamage() > 0
                ? Math.max(0, (stack.getMaxDamage() - stack.getDamage()) * 100 / stack.getMaxDamage()) : 100;
        int color = percent <= 20 ? 0xFFFF6666 : percent <= 50 ? 0xFFFFD37A : 0xFFE2EDF4;
        context.drawTextWithShadow(textRenderer, Text.literal(name + ": " + percent + "%"), x, y, color);
    }

    private void drawPanel(DrawContext context, int x, int y, int w, int h) {
        context.fill(x, y, x + w, y + h, 0xF00A1724);
        context.fill(x, y, x + w, y + 2, 0xFF35C9F5);
        context.fill(x, y + h - 2, x + w, y + h, 0xFF1F88B2);
        context.fill(x, y, x + 2, y + h, 0xFF1F88B2);
        context.fill(x + w - 2, y, x + w, y + h, 0xFF1F88B2);
    }

    private void drawButton(DrawContext context, UiButton button, int mouseX, int mouseY) {
        boolean hover = mouseX >= button.x && mouseX < button.x + button.w && mouseY >= button.y && mouseY < button.y + button.h;
        int bg = hover ? 0xFF175070 : 0xE7132B3B;
        int border = hover ? 0xFF8AF0FF : 0xFF267C9B;
        context.fill(button.x, button.y, button.x + button.w, button.y + button.h, bg);
        context.fill(button.x, button.y, button.x + button.w, button.y + 1, border);
        context.fill(button.x, button.y + button.h - 1, button.x + button.w, button.y + button.h, border);
        context.fill(button.x, button.y, button.x + 1, button.y + button.h, border);
        context.fill(button.x + button.w - 1, button.y, button.x + button.w, button.y + button.h, border);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(button.label), button.x + button.w / 2, button.y + (button.h - 8) / 2, 0xFFEAFBFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        for (UiButton ui : buttons) {
            if (mouseX >= ui.x && mouseX < ui.x + ui.w && mouseY >= ui.y && mouseY < ui.y + ui.h) {
                runAction(ui.action);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void runAction(int action) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (action == ACTION_TOGGLE_ACTIVE) {
            ClientState.active = !ClientState.active;
            ClientPlayNetworking.send(new ToggleSuitPayload(ClientState.active));
        } else if (action == ACTION_OPEN_INFINITY) {
            client.setScreen(new InfinityScreen(this));
        } else if (action == ACTION_OPEN_PORTAL) {
            client.setScreen(new PortalScreen(this));
        } else {
            ClientPlayNetworking.send(new SuitActionPayload(action));
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_J) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private record UiButton(int x, int y, int w, int h, String label, int action) {}
}
